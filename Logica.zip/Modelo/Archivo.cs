﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoSena.Modelo
{
    public class Archivo
    {

        public string Nombre {  get; set; }
        public string Extencion { get; set; }   
        
        public byte [] Contenido  { get; set; }
    }
}
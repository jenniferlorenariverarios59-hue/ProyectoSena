﻿using ProyectoSena.Datos;
using ProyectoSena.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoSena.Logica
{
    public class AprendizL

    {

        AprendizD oAprendizD = new AprendizD();

        public int MtRegistrarAprendiz(AprendizM oAprendiz)
        {
            int Verificacion = 0;

            List<AprendizM> listaAprendiz = oAprendizD.MtObtenerAprendiz();
            var existe = listaAprendiz.Select(u => u.NumeroDocumento == oAprendiz.NumeroDocumento);

            if (existe != null)
            {
                Verificacion = oAprendizD.MtRegistrarAprendiz(oAprendiz);
             
            }
            return Verificacion;

        }

        public List<AprendizM> MtObtenerAprendiz()
        {
            List<AprendizM> listaAprendiz = oAprendizD.MtObtenerAprendiz();
            return listaAprendiz;

        }

        public int MtObtenerAprendiz(AprendizM oAprendiz)
        {
            int Verificacion = oAprendizD.MtEditarAprendiz(oAprendiz);
            return Verificacion;


        }

        public int MtEliminarAprendiz(AprendizM oAprendiz )
        {
            int Verificacion = oAprendizD.MtEliminarAprendiz(oAprendiz);
            return Verificacion;    
        }
    }
}
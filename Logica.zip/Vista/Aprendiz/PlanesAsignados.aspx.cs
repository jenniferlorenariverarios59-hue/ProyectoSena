﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProyectoSena.Vista.Aprendiz
{
    public partial class PlanesAsignados : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void gvPlanesMejoramiento_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }
    }
}